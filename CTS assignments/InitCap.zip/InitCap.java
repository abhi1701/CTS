import java.io.*;
import java.util.*;
public class InitCap {
                public static void main(String[] args) {
                                Scanner sc = new Scanner(System.in);
                                System.out.println("Enter the String:");
                                String str = sc.nextLine();
                                int count=0;
                                int count1=0;           
        char ch1[]= new char[str.length()];     
        for(int i=0;i<str.length();i++)  
        {  
            ch1[i]= str.charAt(i);  
            if( ((i>0)&&(ch1[i]!=' ')&&(ch1[i-1]==' ')) || ((ch1[0]!=' ')&&(i==0)) )  
                count1++; 
        }
                                char ch[] = str.toCharArray();
                                for (int i = 0; i < str.length(); i++) 
                                {                                                 
            if (i == 0 && ch[i] != ' ' || ch[i] != ' ' && ch[i - 1] == ' ') 
            { 
                if (ch[i] >= 'a' && ch[i] <= 'z') 
                {                     
                    ch[i] = (char)(ch[i] - 'a' + 'A'); 
                }
                else if(ch[i]>='A' && ch[i]<='Z')
               {
                              count++;
                }
            }
               
        } 
                                if(count1==count)
                                                System.out.println("First character of each word is already in uppercase");
                                else
                                {
                                                String st = new String(ch);
                                                System.out.println(st);
                                }
                }

}
