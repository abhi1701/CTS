select customer_id,customer_name,ifnull(ifnull(address,email_id),'NA') contact_details
from customers order by customer_id;