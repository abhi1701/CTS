import java.util.Scanner;

import java.lang.*;

public class ReplaceWord {

    public static void main(String[] args) {
                Scanner input = new Scanner(System.in);
                System.out.println("Enter the string:");
                String s1 = input.nextLine();
                
                System.out.println("Enter the word to be searched:");
                String w1 = input.next();
                
                System.out.println("Enter the word to be replaced:");
                String w2 = input.next();
                
                if(s1.indexOf(w1) == -1){
                    System.out.println("The word "+w1+" not found");
                    System.exit(0);
                }
                
                String s2 = s1.replace(w1,w2);
                System.out.println(s2);
                
                
                

    }
}

