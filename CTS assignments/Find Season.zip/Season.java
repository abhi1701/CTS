import java.io.*;
import java.util.*;
public class Season {
                
                public static void main(String[] args){
                                
                                
                                Scanner scanner=new Scanner(System.in);
                                System.out.println("Enter the month:");
                                int i=scanner.nextInt();
                                if(i>12 || i<=0){
                                                System.out.println("Invalid month");
                                }
                                else if(i>=3 && i<=5){
                                                System.out.println("Season:Spring ");
                                }
                                else if(i>=6 && i<=8){
                                                System.out.println("Season:Summer");
                                }
                                else if(i>=9 && i<=11){
                                                System.out.println("Season:Autumn");
                                }
                                else{
                                                System.out.println("Season:Winter");
                                }

                                                
                                }

                }
