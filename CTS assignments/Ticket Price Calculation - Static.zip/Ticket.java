    public class Ticket{
        
    private int ticketid;
	private int price;
	private static int availableTickets;
	public int getTicketid() {
		return ticketid;
	}
	public void setTicketid(int ticketid) {
		this.ticketid = ticketid;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public static int getAvailableTickets() {
		return availableTickets;
	}
	public static void setAvailableTickets(int tick) {
	    if(tick <= 0){
	        availableTickets = 0;
	    }else{
	        availableTickets = tick;
	    }
	}
	
	public int calculateTicketCost(int nooftickets){
	    int totalAmount = 0;
	    if(availableTickets >= nooftickets){
	        totalAmount = nooftickets*price;
	        setAvailableTickets(availableTickets-nooftickets);
	        return totalAmount;
	    }else{
	        return -1;
	    }
	}
	
}