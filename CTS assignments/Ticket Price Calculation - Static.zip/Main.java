import java.util.*;
import java.util.Scanner;
public class Main{
    public static void main(String[] args){
    Ticket t1 = new Ticket();
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter no of bookings:");
    int n = sc.nextInt();
    for(int i=0;i<n;i++){
        System.out.println("Enter the available tickets:");
        t1.setAvailableTickets(sc.nextInt());
        
        System.out.println("Enter the ticketid:");
        t1.setTicketid(sc.nextInt());
        
        System.out.println("Enter the price:");
        t1.setPrice(sc.nextInt());
        
        System.out.println("Enter the no of tickets:");
        int noOf = sc.nextInt();
        
        System.out.println("Available tickets: "+t1.getAvailableTickets());
        System.out.println("Total amount:"+t1.calculateTicketCost(noOf));
        
        System.out.println("Available ticket after booking:"+t1.getAvailableTickets());
        
    }
    }
}