import java.util.regex.*; 
import java.util.Scanner;
public class PanCard {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the PAN no:");
        String pan = s.nextLine();
         if(Pattern.matches("[A-Z]{5}[0-9]{4}[A-Z]",pan))
         {
             System.out.println("Valid PAN no");
         }
         else{
             System.out.println("Invalid PAN no");
         }
        
              
    }
}

