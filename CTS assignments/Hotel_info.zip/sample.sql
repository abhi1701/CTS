select CONCAT(hotel_name,"is", " a",hotel_type,"hotel") as HOTEL_INFO
FROM hotel_details order by HOTEL_INFO desc;