select Distinct owners.owner_id,owners.owner_name,owners.address,owners.phone_no
FROM owners Join cars on owners.owner_id=cars.owner_id where cars.car_name like 'Maruthi%'
order by owners.owner_id;