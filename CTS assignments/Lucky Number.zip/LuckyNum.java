import java.util.*;
import java.io.*;
public class LuckyNum {
                
                
                public static void main(String[] args){
                                Scanner scanner=new Scanner(System.in);
                                
                                int Number, Reminder, Sum = 0;
                                scanner = new Scanner(System.in);                          
                                System.out.println("Enter the car no:");
                                Number = scanner.nextInt();
                                if(Number>=1000 && Number<=9999){
                        while(Number!=0){
                                                Reminder = Number % 10;
                                                Sum = Sum+ Reminder;
                                                Number = Number / 10;
                        }
                                    
                                                if(Sum%3==0 || Sum%5==0 ||Sum%7==0){
                                                System.out.println("Lucky Number");
                                                }
                                
                                    else {
                                                System.out.println("Sorry its not my lucky number");
                                    }
                                }
                                else {
                                                System.out.println(+Number+" is not a valid car number");
                                                System.exit(0);
                                                }
                                }
}

