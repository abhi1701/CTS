import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
       Vehicle v = new Vehicle("123","sedan","4 wheeler",100000.0);
    }
}