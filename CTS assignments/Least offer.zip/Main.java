import java.util.*;
public class Main{
    public static void main (String[] args) {
     Scanner sc=new Scanner(System.in);
     int a=sc.nextInt();
     String s;
     String [] am;
     String [] name=new String[20];
     double [] price=new double[20];
     double total,res;
     for(int i=0;i<a;i++)
     {
         s=sc.next();
         am=s.split(",");
         total=Double.parseDouble(am[1]);
         res=Double.parseDouble(am[2]);
         price[i]=(total*res)/100;
         name[i]=am[0];
     }
     double max=price[0];
     for(int i=1;i<a;i++)
     {
         if(price[i]<max)
         {
             max=price[i];
         }
     }
     for(int i=0;i<a;i++)
     {
         if(max==price[i])
         {
             System.out.println(name[i]);
         }
     }
     
    }
}