import java.util.Scanner;
public class Division
{
    public String divideTwoNumbers(int number1,int number2)
    {
        String str="";
        try {
            int k = number1/number2;
            str = "The answer is "+k+". Thanks for using the application.";
        } 
        catch(ArithmeticException e) {
            str = "Division by zero is not possible. Thanks for using the application.";
            
        }
        return str;
    }
    
    public static void main(String[] args){
        Division d = new Division();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the numbers");
        int n = sc.nextInt();
        int n2 = sc.nextInt();
        System.out.println(d.divideTwoNumbers(n,n2));
    }
}