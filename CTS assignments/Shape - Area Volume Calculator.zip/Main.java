import java.util.*;
public class Main
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        Shape h[]=new Shape[5];
        String shape;
        for(int i=0;i<5;i++)
        {
            shape=sc.next();
            System.out.println(shape);
            if(shape.equals("Triangle"))
            {
                Triangle t=new Triangle();
                t.setBase(sc.nextDouble());
                t.setHeight(sc.nextDouble());
                h[i]=t;
                System.out.println("Area "+h[i].area());
            }
            else if(shape.equals("Sphere"))
            {
                Sphere s=new Sphere();
                s.setRadius(sc.nextDouble());
                h[i]=s;
                System.out.println("Area "+h[i].area());
                System.out.println("Volume "+h[i].volume());
            }
            else if(shape.equals("Rectangle"))
            {
                Rectangle r=new Rectangle();
                r.setLength(sc.nextDouble());
                r.setWidth(sc.nextDouble());
                h[i]=r;
                System.out.println("Area "+h[i].area());
            }
            else
            {
                Cube c=new Cube();
                c.setLength(sc.nextDouble());
                c.setWidth(sc.nextDouble());
                c.setHeight(sc.nextDouble());
                h[i]=c;
                System.out.println("Area "+h[i].area());
                System.out.println("Volume "+h[i].volume());
            }
        }
    }
}