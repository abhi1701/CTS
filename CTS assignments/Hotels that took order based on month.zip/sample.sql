select distinct Hotel_details.hotel_id,Hotel_details.hotel_name,Hotel_details.rating from Hotel_details
inner join orders on Hotel_details.hotel_id=orders.hotel_id where 
order_date between '2019-07-01' and '2019-07-31' order by hotel_id;