import java.util.Scanner;
public class IncrementCalculation
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double sal,ap;
		System.out.println("Enter the salary");
		sal = sc.nextDouble();
		System.out.println("Enter the Performance appraisal rating");
		ap = sc.nextDouble();
		if(sal>0&&ap<=5)
		{
		    if(ap>=1&&ap<=3)
		    {
		        sal+=(sal*0.10);
		        System.out.printf("%.0f",sal);
		    }
		    else if(ap>=3.1&&ap<=4)
		    {
		         sal+=(sal*0.25);
		        System.out.printf("%.0f",sal);
		    }
		    else if(ap>=4.1&&ap<=5)
		    {
		        sal+=(sal*0.30);
		        System.out.printf("%.0f",sal);
		    }
		    
		}
		else{
		    System.out.println("Invalid Input");
		}
		
	}
}