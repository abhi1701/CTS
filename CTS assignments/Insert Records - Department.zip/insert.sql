insert into Department(department_id, department_name, department_block_number) values (1, "CSE", 3);
insert into Department(department_id, department_name, department_block_number) values (2, "IT", 3);
insert into Department(department_id, department_name, department_block_number) values (3, "SE", 3);