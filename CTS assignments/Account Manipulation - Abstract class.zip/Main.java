public class Main{
    
    public static void main(String args[]){
        SavingsAccount s1 = new SavingsAccount(1234,new Customer(1,"RJ","rsreevatsa"),2000.0,100.0);
    }
}