select rental_id,car_id,customer_id,km_driven from Rentals
where return_date between '2019-08-01' and '2019-08-30' 
order by rental_id;