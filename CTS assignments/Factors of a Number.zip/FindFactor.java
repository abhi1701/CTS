import java.util.Scanner;
import java.lang.*;
public class FindFactor{

     public static void main(String []args){
      Scanner sc = new Scanner(System.in);
      int n = sc.nextInt();
      int m = Math.abs(n);
      if(m!=0)
      {
          for(int i=1;i<=m/2;i++){
          if(m%i==0)
          {
              System.out.print(i+",");
          }
          }
          System.out.print(m);
      }
      else{
          System.out.println("No Factors");
      }
      
}
}