import java.io.*;
import java.lang.*;
class PrimeNumbers{
    public static void main (String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int a,b,flag;
        a = Integer.parseInt(br.readLine());
        b = Integer.parseInt(br.readLine());
        if(a>b){
            System.out.println("provide valid input");
            System.exit(0);
        }
        
        if((a<=0)||(b<=0)){
            System.out.println("provide valid input");
            System.exit(0);
        }
        
        if(a==b){
            System.out.println("provide valid input");
            System.exit(0);
        }
        
        if(a<b){
        if((a>0)&&(b>0)){
        for(int i=a;i<=b;i++){
            if(i==1||i==0)
                continue;
            flag =1;
            for (int j=2;j<=i/2;j++){
                if((i%j)==0){
                   flag =0;
                   break;
                }
                
            } 
            if(flag ==1){
                System.out.println(i);
            }
        }
        }
            
        }
    }
}
