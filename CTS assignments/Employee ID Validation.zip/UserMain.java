import java.util.regex.*; 
import java.util.Scanner;
public class UserMain {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter your ID");
        String pan = s.nextLine();
         if(Pattern.matches("[G][B][L][/][0-9]{3}[/][0-9]{4}",pan))
         {
             System.out.println("Login success");
         }
         else{
             System.out.println("Incorrect ID");
         }
        
              
    }
}
