import java.util.*;
import java.util.regex.*;
public class Numerology {
       public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter your name:");
       String str=sc.nextLine();
       int sum=0;
       int a[][]={{65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90},
                    {1,2,3,4,5,8,3,5,1,1,2,3,4,5,7,8,1,2,3,4,6,6,6,5,1,7}};
       Pattern pattern=Pattern.compile("[A-Z]*");
       Matcher matcher=pattern.matcher(str);
       if(!matcher.matches())
       {
          System.out.println("Invalid name");
       }
       else
       {
          int len=str.length();
          
          int j=0,i=0;
         while(j<len)
         {
                int c=(int)str.charAt(j);
                
                i=0;
                while(i<=25)
                {
                      if(c==a[0][i])
                      {
                             sum+=a[1][i];
                             break;
                      }
                      i++;
                }
                j++;
         }
         
          System.out.println("Your numerology no is:"+sum);
       }
}
}
       
