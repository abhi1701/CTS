import java.util.Scanner;
public class SnacksDetails
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    System.out.println("Enter the no of pizzas bought:");
	    int p = sc.nextInt();
	    System.out.println("Enter the no of puffs bought:");
	    int pu = sc.nextInt();
	    System.out.println("Enter the no of cool drinks bought:");
	    int c = sc.nextInt();
	    int total=(p*100)+(pu*20)+(c*10);
	    System.out.println("Bill Details");
	    System.out.println("No of pizzas:"+p);
	    System.out.println("No of puffs:"+pu);
	    System.out.println("No of cooldrinks:"+c);
	     System.out.println("Total price="+total);
	       System.out.println("ENJOY THE SHOW!!!");
	    
	     
	    
	    
	    
	}
}
