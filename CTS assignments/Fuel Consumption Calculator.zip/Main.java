import java.io.*;
import java.util.*;
import java.math.*;
import java.lang.*;
class Main{
    public static void main(String Args[])
    {
        float quantity,dist_dry,x;
        double kms,miles;
        double rounded_kms,rounded_miles;
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the no of liters to fill the tank");
        quantity=s.nextFloat();
        do{
        if(quantity<=0){
            System.out.println(Math.round(quantity)+" is an Invalid Input");
            break;
        }
        System.out.println("Enter the distance covered");
        dist_dry=s.nextFloat();
        if(dist_dry<=0)
        {
            System.out.println(Math.round(dist_dry)+" is an Invalid Input");
            break;
        }
        if(quantity>0 && dist_dry>0)
        {
        kms=quantity/dist_dry*100;
        rounded_kms=Math.round(kms*100)/100.00;
        System.out.println("Liters/100KM");
        System.out.format("%.2f",rounded_kms);
        miles=(dist_dry*0.6214)/(quantity*0.2642);
        rounded_miles=Math.round(miles*100)/100.00;
        System.out.println("\nMiles/gallons");
        System.out.format("%.2f",rounded_miles);
        break;
        }}while(true);
    }
}