import java.util.*;
import java.io.*;
public class CinemaTicket {
                
                public static void main(String args[]){
                                
                                Scanner scanner=new Scanner(System.in);
                                double amount;
                                System.out.println("Enter the no of ticket:");
                                int N=scanner.nextInt();
                                if(N>=5 && N<=40){
                                                System.out.println("Do you want refreshment:");
                                                char r=scanner.next().charAt(0);
                                                System.out.println("Do you have coupon code:");
                                                char cc=scanner.next().charAt(0);
                                                System.out.println("Enter the circle:");
                                                char c=scanner.next().charAt(0);
                                                
                                                if(c=='k' || c=='q'){
                                                                if(c=='k'){
                                                                                amount=N*75;
                                                                                }
                                                                else{
                                                                                amount=N*150;
                                                                }
                                                                if(N>20)
                                                                {
                                                                                amount=amount-amount*0.1;
                                                                }
                                                                if(cc=='y'){
                                                                                amount=amount-amount*0.02;
                                                                }
                                                                if(r=='y'){
                                                                                amount+=N*50;
                                                                }
                                                                System.out.print("Ticket cost:");
                                                                System.out.printf("%.2f", amount);                                         
                                                }
                                                else
                                                                System.out.println("Invalid Input");
                                }
                                else
                                                System.out.println("Minimum of 5 and Maximum of 40 Tickets");
                }

}
