import java.util.*;
import java.io.*;
import java.util.regex.*;
public class Palindrome
{
                public static void main(String args[])
                    {
                        String a, rev="",p;
                        Scanner s = new Scanner(System.in);
                        System.out.println("Enter the word :");
                        a = s.nextLine();
                        int n = a.length();
                        p=a.toLowerCase();
                        if(Pattern.matches("[A-Za-z]+$",p))
                        {
                           for(int i = n - 1; i >= 0; i--)
                           {
                                rev = rev + p.charAt(i);
                           }
                           if(p.equals(rev))
                           {
                               System.out.println(a+" is a Palindrome");
                           }
                           else
                           {
                               System.out.println(a+" is not a Palindrome");
                           }
                        }
                        else
                        {
                               System.out.println("Invalid Input");
                        }
                        
                        
                    }

}
