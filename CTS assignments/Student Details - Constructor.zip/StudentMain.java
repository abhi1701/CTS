import java.util.*;
public class StudentMain{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Student's Id:");
        int id = sc.nextInt();
        
        System.out.println("Enter Student's Name:");
        String name = sc.next();
        
        System.out.println("Enter Student's address:");
        String address = sc.next();
        while(true){
        System.out.println("Whether the student is from NIT(Yes/No):");
        String ans = sc.next();
        if(ans.equals("yes") || ans.equals("YES")){
            Student s1 = new Student(id,name,address);
            System.out.println("Student id:"+id);
        System.out.println("Student name:"+name);
        System.out.println("Address:"+address);
        System.out.println("College name:NIT");
            break;
        }
        else if(ans.equals("no") || ans.equals("NO")){
            System.out.println("Enter the college name:");
            String cllg = sc.next();
            Student s1 = new Student(id,name,address,cllg);
            System.out.println("Student id:"+id);
        System.out.println("Student name:"+name);
        System.out.println("Address:"+address);
        System.out.println("College name:"+cllg);
            break;
        }else{
            System.out.println("Wrong Input");
        }
        
        }
        
        
        
        
    }
}