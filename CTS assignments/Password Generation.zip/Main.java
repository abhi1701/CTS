import java.util.regex.*; 
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Generate your Security Code ");
        String pan = s.nextLine();
         if(Pattern.matches("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#*$%]).{8,})",pan))
         {    System.out.println("Security Code Generated Successfully");
         }
         else{
             System.out.println("Invalid Security Code, Try Again!");
         }
        
              
    }
}
