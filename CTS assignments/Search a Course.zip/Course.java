import java.lang.*;
import java.util.Scanner;
public class Course{

     public static void main(String []args){
         Scanner sc = new Scanner(System.in);
         String c[] = new String[100];
         System.out.println("Enter no of course:");
         int n = sc.nextInt();
         if(n<=0)
         {
             System.out.println("Invalid Range");
             System.exit(0);
         }
         else{
         int count=0;
         System.out.println("Enter course names:");
         for(int i=0;i<=n;i++)
         {
             c[i] = sc.nextLine();
         }
         System.out.println("Enter the course to be searched:");
         String s = sc.nextLine();
         for(int i=0;i<=n;i++)
         {
             if(c[i].equals(s))
             {
                 count++;
                 break;
             }
         }
         if(count==1)
         {
             System.out.println(s+" course is available");
         }
         else
         {
             System.out.println(s+" course is not available");
         }
     }
}
}