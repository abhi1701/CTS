import java.util.*;
public class StudentMain{
    
    public static Student getStudentDetails(){
        Scanner sc = new Scanner(System.in);
        
        int[] arr = new int[10]; 
        System.out.println("Enter the id:");
        int id = sc.nextInt();
        int n;
        
        System.out.println("Enter the name:");
        String name = sc.next();
        while (true){
            System.out.println("Enter the no of subjects:");
            n = sc.nextInt();
            if(n<=0){
                System.out.println("Invalid number of subject");
                continue;
            }else
            break;
        } 
        
        for(int i=1; i<=n;i++){
            while(true){
                System.out.println("Enter mark for subject "+i+":");
                arr[i] = sc.nextInt();
                if(arr[i]<0 || arr[i]>100){
                    System.out.println("Invalid Mark");
                    continue;
                }else
                break;
            }
            
        }
        //s1.setMarks(arr);
        
        Student s1 = new Student(id,name,arr);
        
        return s1;
        
    }
    
    public static void main(String[] args){
        Student s = StudentMain.getStudentDetails();
        System.out.println("Id:"+s.getId());
        System.out.println("Name:"+s.getName());
        s.calculateAvg();
        System.out.printf("Average:%.2f",s.getAverage());
        System.out.println();
        s.findGrade();
        System.out.println("Grade:"+s.getGrade());
    }
}