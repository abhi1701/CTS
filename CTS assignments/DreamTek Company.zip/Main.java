import java.util.*;

public class Main{
    public static void main(String[] args) 
    {
        Associate n=new Associate();
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the associate id:");
        n.setAssociateId(sc.nextInt());
        System.out.println("Enter the associate name:");
        n.setAssociateName(sc.next());
        System.out.println("Enter the number of days:");
        int j=sc.nextInt();
        n.trackAssociateStatus(j);
        System.out.println("The associate "+n.getAssociateName()+" work status:"+n.getWorkStatus());
    }
}