public class Associate{
    private int associateId;
    private String associateName;
    private String workStatus;
    
    public int getAssociateId() {
        return associateId;
    }
    public void setAssociateId(int associateId) {
        this.associateId=associateId;
    }
    public String getAssociateName() {
        return associateName;
    }
    public void setAssociateName(String associateName) {
        this.associateName=associateName;
    }
    public void setWorkStatus(String workStatus) {
        this.workStatus=workStatus;
    }
    public String getWorkStatus() {
        return workStatus;
    }
    public void trackAssociateStatus(int a) {
        if(a<=20) {
            setWorkStatus("Core skills");
        }
        else if(a>20&&a<=40) {
            setWorkStatus("Advanced modules");
        }
        else if(a>40&&a<=60) {
            setWorkStatus("Project phase");
        }
        else{
            setWorkStatus("Deployed in project");
        }
    }
    
    
}