select DISTINCT orders.hotel_id,hotel_details.hotel_name,hotel_details.hotel_type
from orders join hotel_details on orders.hotel_id=hotel_details.hotel_id
where orders.hotel_id not in (select hotel_id from orders where
MONTH(order_date)=05 and YEAR(order_date)=2019);