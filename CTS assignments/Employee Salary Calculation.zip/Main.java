import java.util.*;
public class Main{
    public static Employee getEmployeeDetails(){
        Scanner in=new Scanner(System.in);
        Employee e1=new Employee();
        System.out.println("Enter Id:");
        int id=in.nextInt();
        e1.setEmployeeId(id);
        System.out.println("Enter Name:");
        String name=in.next();
        e1.setEmployeeName(name);
        System.out.println("Enter salary:");
        double salary=in.nextDouble();
        e1.setSalary(salary);
        return e1;
    }
    public static int getPFPercentage(){
        Scanner in=new Scanner(System.in);
        System.out.println("Enter PF percentage:");
        int pf=in.nextInt();
        return pf;
    }
    public static void main (String[] args) {
        Employee emp=getEmployeeDetails();
        int a;
        a=getPFPercentage();
        emp.calculateNetSalary(a);
        System.out.println("Id : "+emp.getEmployeeId());
        System.out.println("Name : "+emp.getEmployeeName());
        System.out.printf("Salary : %.1f",emp.getSalary());
        System.out.print("\nNet Salary : ");
        System.out.printf("%.1f", emp.getNetSalary());
    }
        
    }
