import java.util.*;
public class Employee{
    private int employeeId;
    private String employeeName;
    private double salary;
    private double netSalary;
    
    public int getEmployeeId(){
        return employeeId;
    }
    public void setEmployeeId(int id){
        this.employeeId=id;
    }
    public String getEmployeeName(){
        return employeeName;
    }
    public void setEmployeeName(String name){
        this.employeeName=name;
    }
    public double getSalary(){
        return salary;
    }
    public void setSalary(double sal){
       this.salary=sal;
    }
    public double getNetSalary(){
        return this.netSalary;
    }
    public void setNetSalary(double netSalary){
        this.netSalary=netSalary;
    }
    public void calculateNetSalary(int pf){
        this.netSalary=(salary-(pf*(salary/100)));
        
    }
    
}
