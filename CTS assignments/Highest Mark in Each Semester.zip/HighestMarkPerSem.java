import java.io.*;
import java.lang.reflect.Array;
import java.util.*;
public class HighestMarkPerSem {
                public static void main(String[] args) {
                                Scanner sc =new Scanner(System.in);
                                System.out.println("Enter no of semester:");
                                int n = sc.nextInt();
                                boolean flag = true;
                                int count=0;
                                int sem[] = new int[n];
                                int max[] = new int[n];
                                for(int i=0;i<n;i++)
                                {
                                                System.out.println("Enter no of subjects in "+(i+1)+" semester:");
                                                sem[i]=sc.nextInt();
                                }
                                for(int i=0;i<n;i++)
                                {
                                                System.out.println("Marks obtained in semester "+(i+1)+":");
                                                int marks[] = new int[sem[i]];
                                                for(int j=0;j<sem[i];j++)
                                                {
                                                                marks[j] = sc.nextInt();
                                                                if(marks[j]>100 || marks[j]<1)
                                                                {
                                                                                flag = false;
                                                                                break;
                                                                }
                                                                
                                                }
                                                if(flag == false)
                                                {
                                                                System.out.println("You have entered invalid mark.");
                                                                break;
                                                }
                                                else
                                                {
                                                                Arrays.sort(marks);
                                                                max[i] = marks[sem[i]-1];                                             
                                                }
                                }
                                for(int p=0;p<n;p++)
                                {
                                                if(max[p]!=0)
                                                {
                                                                count++;
                                                }
                                }
                                if(count==n)
                                {
                                                for(int k=0;k<n;k++)
                                                                System.out.println("Maximum mark in "+(k+1)+" semester:"+max[k]);
                                }
                                

                }

}

