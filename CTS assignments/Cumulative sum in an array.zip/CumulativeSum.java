import java.util.Scanner;
 
public class CumulativeSum
{
   public static void main(String args[])
   {
      String str, rev = "";
      int a[] = new int[100];
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter number of elements");
      int n = sc.nextInt();
      if(n>0){
      System.out.println("Enter the elements");
      for(int i=0;i<n;i++)
      a[i] = sc.nextInt();
      int sum=0;
      for(int i=0;i<n;i++)
      {
          sum=sum+a[i];
          System.out.print(sum+" ");
      }
      }
      else{
          System.out.println("Invalid Range");
      }
      
   }
}