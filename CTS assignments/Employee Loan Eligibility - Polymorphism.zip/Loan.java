
public class Loan {
	
	//Implement the below method 
	
	public double calculateLoanAmount(Employee employeeObj) {
		if(employeeObj instanceof PermanentEmployee){
		    double loan = (15*employeeObj.salary)/100;
		    return loan;
		}else{
		    double loan = (10*employeeObj.salary)/100;
		    return loan;
		}
	}

}
