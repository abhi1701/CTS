import java.util.regex.*; 
import java.util.Scanner;
public class UniqueChar{
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the sentence:");
        String sent = s.nextLine();
         if(!Pattern.matches("^[ A-Za-z]+$",sent))
         {
             System.out.println("Invalid Sentence");
         }
         else{
             int[] count = new int[256]; 
             
             int i; 
        for (i = 0; i < sent.length(); i++) 
            if(sent.charAt(i)!=' ') 
                count[(int)sent.charAt(i)]++; 
                int n = i; 
                int d=0;
        for (i = 0; i < n; i++) 
           {
               if (count[(int)sent.charAt(i)] == 1) 
               {
                   d++;
                   break;
               }
           }  
       if(d==0)
       {
           System.out.print("No unique characters");
       }
     else{
         System.out.print("Unique characters:");
     
        for (i = 0; i < n; i++) 
            if (count[(int)sent.charAt(i)] == 1) 
                System.out.print(sent.charAt(i)+" ");
         }}
         
        
              
    }
}

