import java.util.*;
public class Main{
    
    public static Hosteller getHostellerDetails(){
            Hosteller h1 = new Hosteller();
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter the Details:");
            System.out.println("Student Id");
            int id = sc.nextInt();
            System.out.println("Student Name");
            String name = sc.next();
            System.out.println("Department Id");
            int dept_id = sc.nextInt();
            System.out.println("Gender");
            String gender = sc.next();
            
            System.out.println("Phone Number");
            String phone = sc.next();
            
            System.out.println("Hostel Name");
            String hostel = sc.next();
            
            System.out.println("Room Number");
            int room_no = sc.nextInt();
            
            h1.setHostelName(hostel);
            h1.setRoomNumber(room_no);
            h1.setStudentId(id);
            h1.setName(name);
            h1.setDepartmentId(dept_id);
            h1.setGender(gender);
            h1.setPhone(phone);
            
            
            return h1;
            
        }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        Hosteller h = Main.getHostellerDetails();
        System.out.println("Modify Room Number(Y/N)");
        String ans = sc.next();
        if(ans.equals("Y")){
            System.out.println("New Room Number");
            h.setRoomNumber(sc.nextInt());
        }
        System.out.println("Modify Phone Number(Y/N)");
        ans = sc.next();
        if(ans.equals("Y")){
            System.out.println("New Phone Number");
            h.setPhone(sc.next());
        }
        System.out.println("The Student Details");
        System.out.println(h.getStudentId()+" "+h.getName()+" "+h.getDepartmentId()+" "+h.getGender()+" "+h.getPhone()+" "+h.getHostelName()+" "+h.getRoomNumber());
    }
}