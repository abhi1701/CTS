select orders.hotel_id,hotel_details.hotel_name,count(*) as NO_OF_ORDERS FROM 
orders join hotel_details on orders.hotel_id=hotel_details.hotel_id
group by orders.hotel_id having count(*)>5
order by orders.hotel_id;