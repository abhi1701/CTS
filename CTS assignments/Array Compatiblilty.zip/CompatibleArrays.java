import java.util.*;
public class CompatibleArrays
{
    public static void main (String[] args) {
    Scanner sc = new Scanner(System.in);
                                System.out.println("Enter the size for First array:");
                                int size1 = sc.nextInt();
                                int count = 0;
                                if (size1 <= 0) {
                                                System.out.println("Invalid array size");
                                                System.exit(0);
                                }
                                int array1[] = new int[size1];
                                System.out.println("Enter the elements for First array:");
                                for (int i = 0; i < size1; i++) {
                                                array1[i] = sc.nextInt();
                                }
                                System.out.println("Enter the size for Second array:");
                                int size2 = sc.nextInt();
                                if (size2 <= 0) {
                                                System.out.println("Invalid array size");
                                                System.exit(0);
                                }
                                int array2[] = new int[size2];
                                System.out.println("Enter the elements for Second array:");
                                for (int j = 0; j < size2; j++) {
                                                array2[j] = sc.nextInt();
                                }
                                if (size1 != size2)
                                                System.out.println("Arrays are Not Compatible");
                                else {
                                                for (int k = 0; k < size1; k++) {
                                                                if (array1[k] >= array2[k])
                                                                                count++;
                                                }
                                                if (count < size1)
                                                                System.out.println("Arrays are Not Compatible");
                                                else
                                                                System.out.println("Arrays are Compatible");
                                }

    }
}
