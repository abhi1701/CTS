select concat(owner_name,owner_id) AS USERNAME,concat(LEFT(owner_name,3),owner_id) AS PASSWORD FROM 
OWNERS ORDER BY owner_name;